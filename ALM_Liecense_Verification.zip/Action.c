Action()
{
	
	


	lr_start_transaction("CH2_CRM_S01_QryCustIdenScreen_T01_Homepage");
	
	
                                            
   lr_end_transaction("CH2_CRM_S01_QryCustIdenScreen_T01_Homepage",LR_AUTO);

	return 0;
}