Action()
{
	lr_start_transaction("CH2_CRM_S01_QryCustIdenScreen_T05_EnterAccountClkSearch");

	web_custom_request("BSPWDApplication.do", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/bc/bsp/sap/crm_ui_frame/BSPWDApplication.do", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/bc/bsp/sap/crm_ui_frame/BSPWDApplication.do", 
		"Snapshot=t53.inf", 
		"Mode=HTML", 
		"Body=htmlbevt_ty=htmlb%3Abutton%3Aclick%3A0&htmlbevt_frm=myFormId&htmlbevt_oid=C3_W18_V19_V20_Search&htmlbevt_id=search&htmlbevt_cnt=0&onInputProcessing=htmlb&SVH_INPUTFIELD_ID=&SVH_INPUTFIELD_VALUE=&thtmlbModifiedInputfieldIds=&sap-htmlb-design=&sap-ajaxtarget=C1_W1_V2_C1_W1_V2_V3_C2_W12_V13_C2_W12_V13_V14_C3_W18_V19_C3_W18_V19_V20_bupasearchb2b.do&sap-ajax_dh_mode=AUTO&wcf-secure-id={c_WcfSecureID}&thtmlbKeyboardFocusId=C3_W18_V19_V20_Search&thtmlbKeyboardSelectId=&"
		"thtmlbSliderState=&th-navbar-state=&PREFIX_ID=C9_W35_V36_&C9_W35_V36_SCRATCHPAD_TEXT=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_PREVIOUS_ALERTS=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_PREVIOUS_HASMORE=&C9_W35_V36_CONTEXTAREA_DNISDISPLAY_PREVIOUS_INFO=&C9_W35_V36_CONTEXTAREA_TOPIC_ID=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_MESSAGE=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_HASLINK=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_CODE=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE1=&"
		"C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE2=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE3=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE4=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE5=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE6=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE7=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE8=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE9=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE10=&"
		"C9_W35_V36_SCRATCHPAD_DUMMY_FIELD=&C9_W35_V36_ACTION_GUID=&C9_W35_V36_AC_OBJECT_KEY=&C9_W35_V36_AC_VALUE=&C9_W35_V36_AC_CONTAINER=&C9_W35_V36_MYITSLOCATION=&C9_W35_V36_POLLFREE_ALERTS=%7B%26%2334%3BAlerts%26%2334%3B%3A%5B%5D%7D&C9_W35_V36_REMOVED_NP_ALERTS=&crmFrwScrollXPos=0&crmFrwScrollYPos=0&crmFrwOldScrollXPos=0&crmFrwOldScrollYPos=0&flashIslandsAsString=&callbackFlashIslands=%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)"
		"%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLBX_FLASH_ISLAND&silverlightIslandsAsString=&callbackSilverlightIslands=%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLBX_SILVERLIGHT_ISLAND&th-mes-isex=&C1_W1_V2_V3_V45_bchistory_selection=&C3_W18_V19_V20_searchcustomer_struct.partner={P_AccountNum}&C3_W18_V19_V20_searchcustomer_struct.reltyp=BUR001&C4_W22_V23_V24_tv1_editMode=NONE&"
		"C4_W22_V23_V24_tv1_isCellerator=TRUE&C4_W22_V23_V24_tv1_selectedRows=&C4_W22_V23_V24_tv1_rowCount=0&C4_W22_V23_V24_tv1_lastSelectedRow=&C4_W22_V23_V24_tv1_visibleFirstRow=1&C4_W22_V23_V24_tv1_scrollPosition=&C4_W22_V23_V24_tv1_hscrollPosition=&C4_W22_V23_V24_tv1_bindingString=%2F%2FCUSTOMERS%2FTable&C4_W22_V23_V24_tv1_fixedColumns=&C4_W22_V23_V24_tv1_filterApplied=FALSE&C4_W22_V23_V24_tv1_firstSelectedRow=&C4_W22_V23_V24_tv1_ctrlShiftKeyMode=&C4_W22_V23_V24_tv1_previousSelectedRange=&"
		"C4_W22_V23_V24_tv1_isNavModeActivated=TRUE&C4_W22_V23_V24_tv1_tableIsFiltered=&C4_W22_V23_V24_tv1_multiParameter=0%2F%2F%2F%2F0%2F%2F%2F%2F0%2F%2F%2F%2F0&thtmlbScrollAreaWidth=0&thtmlbScrollAreaHeight=0&LTX_PREFIX_ID=C1_W1_V2_&C1_W1_V2_LTX_VETO_FLAG=&C1_W1_V2_ACTION_GUID=&C1_W1_V2_AC_OBJECT_KEY=&C1_W1_V2_AC_VALUE=&C1_W1_V2_AC_CONTAINER=&C1_W1_V2_MYITSLOCATION=&sap-ajax_request=X", 
		EXTRARES, 
		"Url=/SAP(====)/BC/BSP/SAP/thtmlb_styles/sap_skins/default/styling/pager_back.gif", ENDITEM, 
		"Url=/SAP(====)/BC/BSP/SAP/thtmlb_styles/sap_skins/default/styling/table_edge_bottom_right.gif", ENDITEM, 
		"Url=/SAP(====)/BC/BSP/SAP/thtmlb_styles/sap_skins/default/styling/table_edge_pager_left.gif", ENDITEM, 
		"Url=/SAP(====)/BC/BSP/SAP/thtmlb_styles/sap_skins/default/styling/pager_forward.gif", ENDITEM, 
		LAST);


	web_custom_request("uif_callback_5", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/webcuif/uif_callback", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/bc/bsp/sap/crm_ui_frame/BSPWDApplication.do", 
		"Snapshot=t55.inf", 
		"Mode=HTML", 
		"Body=crm_handler=CL_THTMLB_CELLERATOR&crm_controller=C4_W22_V23_V48&method=fakeScrolling&htmlbScrollX=0&htmlbScrollY=0&htmlbevt_ty=&htmlbdoc_id=&htmlbevt_frm=myFormId&htmlbevt_oid=&htmlbevt_id=&htmlbevt_cnt=0&htmlbevt_par1=&htmlbevt_par2=&htmlbevt_par3=&htmlbevt_par4=&htmlbevt_par5=&htmlbevt_par6=&htmlbevt_par7=&htmlbevt_par8=&htmlbevt_par9=&onInputProcessing=htmlb&myFormId_complete=&SVH_INPUTFIELD_ID=&SVH_INPUTFIELD_VALUE=&thtmlbModifiedInputfieldIds=&sap-htmlb-design=&sap-ajaxtarget="
		"C1_W1_V2_C1_W1_V2_V3_C2_W12_V13_C2_W12_V13_V14_C3_W18_V19_C3_W18_V19_V20_bupasearchb2b.do&sap-ajax_dh_mode=AUTO&wcf-secure-id={c_WcfSecureID}&thtmlbKeyboardFocusId=C3_W18_V19_V20_Search&thtmlbKeyboardSelectId=&thtmlbSliderState=&th-navbar-state=&PREFIX_ID=C9_W35_V36_&C9_W35_V36_SCRATCHPAD_TEXT=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_PREVIOUS_ALERTS=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_PREVIOUS_HASMORE=&C9_W35_V36_CONTEXTAREA_DNISDISPLAY_PREVIOUS_INFO=&C9_W35_V36_CONTEXTAREA_TOPIC_ID="
		"&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_MESSAGE=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_HASLINK=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_CODE=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE1=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE2=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE3=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE4=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE5=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE6=&"
		"C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE7=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE8=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE9=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE10=&C9_W35_V36_SCRATCHPAD_DUMMY_FIELD=&C9_W35_V36_ACTION_GUID=&C9_W35_V36_AC_OBJECT_KEY=&C9_W35_V36_AC_VALUE=&C9_W35_V36_AC_CONTAINER=&C9_W35_V36_MYITSLOCATION=&C9_W35_V36_POLLFREE_ALERTS=%7B%26%2334%3BAlerts%26%2334%3B%3A%5B%5D%7D&C9_W35_V36_REMOVED_NP_ALERTS=&crmFrwScrollXPos=0&"
		"crmFrwScrollYPos=0&crmFrwOldScrollXPos=0&crmFrwOldScrollYPos=0&flashIslandsAsString=&callbackFlashIslands=%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLBX_FLASH_ISLAND&silverlightIslandsAsString=&callbackSilverlightIslands=%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLBX_SILVERLIGHT_ISLAND&"
		"th-mes-isex=&C1_W1_V2_V3_V45_bchistory_selection=&C13_W51_V52_V55_V53_contactinfo_contactinfotype=2&C4_W22_V23_V48_searchcustomer_reltyp=BUR001&C4_W22_V23_V48_tv1_editMode=NONE&C4_W22_V23_V48_tv1_isCellerator=TRUE&C4_W22_V23_V48_tv1_selectedRows=&C4_W22_V23_V48_tv1_rowCount=67&C4_W22_V23_V48_tv1_lastSelectedRow=&C4_W22_V23_V48_tv1_visibleFirstRow=1&C4_W22_V23_V48_tv1_scrollPosition=&C4_W22_V23_V48_tv1_hscrollPosition=&C4_W22_V23_V48_tv1_bindingString=%2F%2FContactRelation%2FTable&"
		"C4_W22_V23_V48_tv1_fakeScrollingURL=%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLB_CELLERATOR%26crm_controller%3DC4_W22_V23_V48%26method%3DfakeScrolling&C4_W22_V23_V48_tv1_fakeVisibleFirstRow=&C4_W22_V23_V48_tv1_fixedColumns=&C4_W22_V23_V48_tv1_filterApplied=FALSE&C4_W22_V23_V48_tv1_firstSelectedRow=&C4_W22_V23_V48_tv1_ctrlShiftKeyMode=&C4_W22_V23_V48_tv1_previousSelectedRange=&"
		"C4_W22_V23_V48_tv1_isNavModeActivated=TRUE&C4_W22_V23_V48_tv1_fakeScrollingNextRow=4%20&C4_W22_V23_V48_tv1_fakeScrollingPreviousRow=none&C4_W22_V23_V48_tv1_fakeScrollingPasteSize=&C4_W22_V23_V48_tv1_fillEmptyRows=&C4_W22_V23_V48_tv1_tableIsFiltered=&C4_W22_V23_V48_tv1_multiParameter=0%2F%2F%2F%2F0%2F%2F%2F%2F0%2F%2F%2F%2F0&thtmlbScrollAreaWidth=0&thtmlbScrollAreaHeight=0&LTX_PREFIX_ID=C1_W1_V2_&C1_W1_V2_LTX_VETO_FLAG=&C1_W1_V2_ACTION_GUID=&C1_W1_V2_AC_OBJECT_KEY=&C1_W1_V2_AC_VALUE=&"
		"C1_W1_V2_AC_CONTAINER=&C1_W1_V2_MYITSLOCATION=&&customFakeRequest=true&fakeScrollingTableId=C4_W22_V23_V48_tv1&rowsToBeRendered=4%2C5%2C6%2C7%2C8%2C9%2C10%2C11%2C12%2C13%2C14%2C15%2C16%2C17%2C18%2C19%2C20%2C21", 
		LAST);


	lr_end_transaction("CH2_CRM_S01_QryCustIdenScreen_T05_EnterAccountClkSearch",LR_AUTO);

	lr_think_time(TT);

	lr_start_transaction("CH2_CRM_S01_QryCustIdenScreen_T06_SelFirstContactPerson");


	web_custom_request("BSPWDApplication.do_2", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/bc/bsp/sap/crm_ui_frame/BSPWDApplication.do", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/bc/bsp/sap/crm_ui_frame/BSPWDApplication.do", 
		"Snapshot=t75.inf", 
		"Mode=HTML", 
		"Body=htmlbevt_ty=thtmlb%3AtableView%3ArowSelection%3A0&htmlbevt_frm=myFormId&htmlbevt_oid=C4_W22_V23_V48_tv1&htmlbevt_id=select&htmlbevt_cnt=1&htmlbevt_par1=1%2C1%2C20%2C67%2CP&onInputProcessing=htmlb&SVH_INPUTFIELD_ID=&SVH_INPUTFIELD_VALUE=&thtmlbModifiedInputfieldIds=&sap-htmlb-design=&sap-ajaxtarget=C1_W1_V2_C1_W1_V2_V3_C2_W12_V13_C2_W12_V13_V14_C4_W22_V23_C4_W22_V23_V48_bupaselectcpforcustomer.do&sap-ajax_dh_mode=AUTO&wcf-secure-id={c_WcfSecureID}&thtmlbKeyboardFocusId="
		"C4_W22_V23_V48_tv1_sel_1-rowsel&thtmlbKeyboardSelectId=&thtmlbSliderState=&th-navbar-state=&PREFIX_ID=C9_W35_V36_&C9_W35_V36_SCRATCHPAD_TEXT=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_PREVIOUS_ALERTS=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_PREVIOUS_HASMORE=&C9_W35_V36_CONTEXTAREA_DNISDISPLAY_PREVIOUS_INFO=&C9_W35_V36_CONTEXTAREA_TOPIC_ID=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_MESSAGE=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_HASLINK=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_CODE=&"
		"C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE1=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE2=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE3=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE4=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE5=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE6=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE7=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE8=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE9=&"
		"C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE10=&C9_W35_V36_SCRATCHPAD_DUMMY_FIELD=&C9_W35_V36_ACTION_GUID=&C9_W35_V36_AC_OBJECT_KEY=&C9_W35_V36_AC_VALUE=&C9_W35_V36_AC_CONTAINER=&C9_W35_V36_MYITSLOCATION=&C9_W35_V36_POLLFREE_ALERTS=%7B%26%2334%3BAlerts%26%2334%3B%3A%5B%5D%7D&C9_W35_V36_REMOVED_NP_ALERTS=&crmFrwScrollXPos=0&crmFrwScrollYPos=0&crmFrwOldScrollXPos=0&crmFrwOldScrollYPos=0&flashIslandsAsString=&callbackFlashIslands=%2Fsap"
		"(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLBX_FLASH_ISLAND&silverlightIslandsAsString=&callbackSilverlightIslands=%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLBX_SILVERLIGHT_ISLAND&th-mes-isex=&C1_W1_V2_V3_V45_bchistory_selection=&C13_W51_V52_V55_V53_contactinfo_contactinfotype=2&"
		"C4_W22_V23_V48_searchcustomer_reltyp=BUR001&C4_W22_V23_V48_tv1_editMode=NONE&C4_W22_V23_V48_tv1_isCellerator=TRUE&C4_W22_V23_V48_tv1_selectedRows=1&C4_W22_V23_V48_tv1_rowCount=67&C4_W22_V23_V48_tv1_lastSelectedRow=1&C4_W22_V23_V48_tv1_visibleFirstRow=1&C4_W22_V23_V48_tv1_scrollPosition=&C4_W22_V23_V48_tv1_hscrollPosition=&C4_W22_V23_V48_tv1_bindingString=%2F%2FContactRelation%2FTable&C4_W22_V23_V48_tv1_fakeScrollingURL=%2Fsap"
		"(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLB_CELLERATOR%26crm_controller%3DC4_W22_V23_V48%26method%3DfakeScrolling&C4_W22_V23_V48_tv1_fakeVisibleFirstRow=&C4_W22_V23_V48_tv1_fixedColumns=&C4_W22_V23_V48_tv1_filterApplied=FALSE&C4_W22_V23_V48_tv1_firstSelectedRow=1&C4_W22_V23_V48_tv1_ctrlShiftKeyMode=&C4_W22_V23_V48_tv1_previousSelectedRange=&C4_W22_V23_V48_tv1_isNavModeActivated=TRUE&"
		"C4_W22_V23_V48_tv1_fakeScrollingNextRow=4%20&C4_W22_V23_V48_tv1_fakeScrollingPreviousRow=none&C4_W22_V23_V48_tv1_fakeScrollingPasteSize=&C4_W22_V23_V48_tv1_fillEmptyRows=&C4_W22_V23_V48_tv1_tableIsFiltered=&C4_W22_V23_V48_tv1_multiParameter=0%2F%2F%2F%2F0%2F%2F%2F%2F0%2F%2F%2F%2F0&thtmlbScrollAreaWidth=0&thtmlbScrollAreaHeight=0&LTX_PREFIX_ID=C1_W1_V2_&C1_W1_V2_LTX_VETO_FLAG=&C1_W1_V2_ACTION_GUID=&C1_W1_V2_AC_OBJECT_KEY=&C1_W1_V2_AC_VALUE=&C1_W1_V2_AC_CONTAINER=&C1_W1_V2_MYITSLOCATION=&"
		"sap-ajax_request=X", 
		LAST);

	web_custom_request("uif_callback_6", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/webcuif/uif_callback", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/bc/bsp/sap/crm_ui_frame/BSPWDApplication.do", 
		"Snapshot=t77.inf", 
		"Mode=HTML", 
		"Body=crm_handler=CL_THTMLB_CELLERATOR&crm_controller=C4_W22_V23_V48&method=fakeScrolling&htmlbScrollX=0&htmlbScrollY=0&htmlbevt_ty=&htmlbdoc_id=&htmlbevt_frm=myFormId&htmlbevt_oid=&htmlbevt_id=&htmlbevt_cnt=0&htmlbevt_par1=&htmlbevt_par2=&htmlbevt_par3=&htmlbevt_par4=&htmlbevt_par5=&htmlbevt_par6=&htmlbevt_par7=&htmlbevt_par8=&htmlbevt_par9=&onInputProcessing=htmlb&myFormId_complete=&SVH_INPUTFIELD_ID=&SVH_INPUTFIELD_VALUE=&thtmlbModifiedInputfieldIds=&sap-htmlb-design=&sap-ajaxtarget="
		"C1_W1_V2_C1_W1_V2_V3_C2_W12_V13_C2_W12_V13_V14_C4_W22_V23_C4_W22_V23_V48_bupaselectcpforcustomer.do&sap-ajax_dh_mode=AUTO&wcf-secure-id={c_WcfSecureID}&thtmlbKeyboardFocusId=C4_W22_V23_V48_tv1_sel_1-rowsel&thtmlbKeyboardSelectId=&thtmlbSliderState=&th-navbar-state=&PREFIX_ID=C9_W35_V36_&C9_W35_V36_SCRATCHPAD_TEXT=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_PREVIOUS_ALERTS=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_PREVIOUS_HASMORE=&C9_W35_V36_CONTEXTAREA_DNISDISPLAY_PREVIOUS_INFO=&"
		"C9_W35_V36_CONTEXTAREA_TOPIC_ID=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_MESSAGE=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_HASLINK=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_CODE=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE1=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE2=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE3=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE4=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE5=&"
		"C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE6=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE7=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE8=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE9=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE10=&C9_W35_V36_SCRATCHPAD_DUMMY_FIELD=&C9_W35_V36_ACTION_GUID=&C9_W35_V36_AC_OBJECT_KEY=&C9_W35_V36_AC_VALUE=&C9_W35_V36_AC_CONTAINER=&C9_W35_V36_MYITSLOCATION=&C9_W35_V36_POLLFREE_ALERTS=%7B%26%2334%3BAlerts%26%2334%3B%3A%5B%5D%7D&"
		"C9_W35_V36_REMOVED_NP_ALERTS=&crmFrwScrollXPos=0&crmFrwScrollYPos=0&crmFrwOldScrollXPos=0&crmFrwOldScrollYPos=0&flashIslandsAsString=&callbackFlashIslands=%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLBX_FLASH_ISLAND&silverlightIslandsAsString=&callbackSilverlightIslands=%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)"
		"%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLBX_SILVERLIGHT_ISLAND&th-mes-isex=&C1_W1_V2_V3_V45_bchistory_selection=&C13_W51_V52_V55_V53_contactinfo_contactinfotype=1&C4_W22_V23_V48_searchcustomer_reltyp=BUR001&C4_W22_V23_V48_tv1_editMode=NONE&C4_W22_V23_V48_tv1_isCellerator=TRUE&C4_W22_V23_V48_tv1_selectedRows=1&C4_W22_V23_V48_tv1_rowCount=67&C4_W22_V23_V48_tv1_lastSelectedRow=&C4_W22_V23_V48_tv1_visibleFirstRow=1&C4_W22_V23_V48_tv1_scrollPosition=&C4_W22_V23_V48_tv1_hscrollPosition=&"
		"C4_W22_V23_V48_tv1_bindingString=%2F%2FContactRelation%2FTable&C4_W22_V23_V48_tv1_fakeScrollingURL=%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLB_CELLERATOR%26crm_controller%3DC4_W22_V23_V48%26method%3DfakeScrolling&C4_W22_V23_V48_tv1_fakeVisibleFirstRow=&C4_W22_V23_V48_tv1_fixedColumns=&C4_W22_V23_V48_tv1_filterApplied=FALSE&C4_W22_V23_V48_tv1_firstSelectedRow=1&"
		"C4_W22_V23_V48_tv1_ctrlShiftKeyMode=&C4_W22_V23_V48_tv1_previousSelectedRange=&C4_W22_V23_V48_tv1_isNavModeActivated=TRUE&C4_W22_V23_V48_tv1_fakeScrollingNextRow=4%20&C4_W22_V23_V48_tv1_fakeScrollingPreviousRow=none&C4_W22_V23_V48_tv1_fakeScrollingPasteSize=&C4_W22_V23_V48_tv1_fillEmptyRows=&C4_W22_V23_V48_tv1_tableIsFiltered=&C4_W22_V23_V48_tv1_multiParameter=0%2F%2F%2F%2F0%2F%2F%2F%2F0%2F%2F%2F%2F0&thtmlbScrollAreaWidth=0&thtmlbScrollAreaHeight=0&LTX_PREFIX_ID=C1_W1_V2_&C1_W1_V2_LTX_VETO_FLAG=&"
		"C1_W1_V2_ACTION_GUID=&C1_W1_V2_AC_OBJECT_KEY=&C1_W1_V2_AC_VALUE=&C1_W1_V2_AC_CONTAINER=&C1_W1_V2_MYITSLOCATION=&&customFakeRequest=true&fakeScrollingTableId=C4_W22_V23_V48_tv1&rowsToBeRendered=", 
		LAST);

	
	lr_end_transaction("CH2_CRM_S01_QryCustIdenScreen_T06_SelFirstContactPerson",LR_AUTO);

	lr_think_time(TT);
	

	lr_start_transaction("CH2_CRM_S01_QryCustIdenScreen_T07_ClkConfirm");

	web_custom_request("sam_js2bsp_sender.htm_2", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/sam_sess_queue/sam_js2bsp_sender.htm?sap-session_access_token={C_AccessToken}=", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/mcmain_header.htm", 
		"Snapshot=t92.inf", 
		"Mode=HTML", 
		"Body=queue=http%3A%2F%2Fch2app01.mckesson.com%3A8020%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)%2Fbc%2Fbsp%2Fsap%2Fsam_sess_queue%2Fsam_session_queue_cntrler.do%3Fsap-session_access_token%3D{C_AccessToken}%3D&type=text&data=null&n0=_sam_js_poll&v0=true&n1=_sam_js_client_queue_receiver_name&v1=CL_SAM_CLIENT_QUEUE_RECEIVER&n2=_sam_bsp_session_queue&v2="
		"http%3A%2F%2Fch2app01.mckesson.com%3A8020%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)%2Fbc%2Fbsp%2Fsap%2Fsam_sess_queue%2Fsam_session_queue_cntrler.do%3Fsap-session_access_token%3D{C_AccessToken}%3D&n3=_sam_message_sent_time&v3=Thu%2C%2012%20Oct%202017%2006%3A00%3A30%20UTC", 
		LAST);

	web_custom_request("BSPWDApplication.do_3", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/bc/bsp/sap/crm_ui_frame/BSPWDApplication.do", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/bc/bsp/sap/crm_ui_frame/BSPWDApplication.do", 
		"Snapshot=t94.inf", 
		"Mode=HTML", 
		"Body=htmlbevt_ty=htmlb%3Abutton%3Aclick%3A0&htmlbevt_frm=myFormId&htmlbevt_oid=C13_W51_V52_V55_Confirm&htmlbevt_id=confirm&htmlbevt_cnt=0&onInputProcessing=htmlb&SVH_INPUTFIELD_ID=&SVH_INPUTFIELD_VALUE=&thtmlbModifiedInputfieldIds=&sap-htmlb-design=&sap-ajaxtarget=C1_W1_V2_C1_W1_V2_V3_C2_W12_V13_C2_W12_V13_V14_C13_W51_V52_C13_W51_V52_V55_bupadetb2bvs.do&sap-ajax_dh_mode=AUTO&wcf-secure-id={c_WcfSecureID}&thtmlbKeyboardFocusId=C13_W51_V52_V55_Confirm&thtmlbKeyboardSelectId=&"
		"thtmlbSliderState=&th-navbar-state=&PREFIX_ID=C9_W35_V36_&C9_W35_V36_SCRATCHPAD_TEXT=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_PREVIOUS_ALERTS=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_PREVIOUS_HASMORE=&C9_W35_V36_CONTEXTAREA_DNISDISPLAY_PREVIOUS_INFO=&C9_W35_V36_CONTEXTAREA_TOPIC_ID=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_MESSAGE=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_HASLINK=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_CODE=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE1=&"
		"C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE2=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE3=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE4=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE5=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE6=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE7=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE8=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE9=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE10=&"
		"C9_W35_V36_SCRATCHPAD_DUMMY_FIELD=&C9_W35_V36_ACTION_GUID=&C9_W35_V36_AC_OBJECT_KEY=&C9_W35_V36_AC_VALUE=&C9_W35_V36_AC_CONTAINER=&C9_W35_V36_MYITSLOCATION=&C9_W35_V36_POLLFREE_ALERTS=%7B%26%2334%3BAlerts%26%2334%3B%3A%5B%5D%7D&C9_W35_V36_REMOVED_NP_ALERTS=&crmFrwScrollXPos=0&crmFrwScrollYPos=0&crmFrwOldScrollXPos=0&crmFrwOldScrollYPos=0&flashIslandsAsString=&callbackFlashIslands=%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)"
		"%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLBX_FLASH_ISLAND&silverlightIslandsAsString=&callbackSilverlightIslands=%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLBX_SILVERLIGHT_ISLAND&th-mes-isex=&C1_W1_V2_V3_V45_bchistory_selection=&C13_W51_V52_V55_V53_contactinfo_contactinfotype=1&C4_W22_V23_V48_searchcustomer_reltyp=BUR001&C4_W22_V23_V48_tv1_editMode=NONE&C4_W22_V23_V48_tv1_isCellerator="
		"TRUE&C4_W22_V23_V48_tv1_selectedRows=1&C4_W22_V23_V48_tv1_rowCount=67&C4_W22_V23_V48_tv1_lastSelectedRow=&C4_W22_V23_V48_tv1_visibleFirstRow=1&C4_W22_V23_V48_tv1_scrollPosition=&C4_W22_V23_V48_tv1_hscrollPosition=&C4_W22_V23_V48_tv1_bindingString=%2F%2FContactRelation%2FTable&C4_W22_V23_V48_tv1_fakeScrollingURL=%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)"
		"%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLB_CELLERATOR%26crm_controller%3DC4_W22_V23_V48%26method%3DfakeScrolling&C4_W22_V23_V48_tv1_fakeVisibleFirstRow=&C4_W22_V23_V48_tv1_fixedColumns=&C4_W22_V23_V48_tv1_filterApplied=FALSE&C4_W22_V23_V48_tv1_firstSelectedRow=1&C4_W22_V23_V48_tv1_ctrlShiftKeyMode=&C4_W22_V23_V48_tv1_previousSelectedRange=&C4_W22_V23_V48_tv1_isNavModeActivated=TRUE&C4_W22_V23_V48_tv1_fakeScrollingNextRow=4%20&C4_W22_V23_V48_tv1_fakeScrollingPreviousRow=none&"
		"C4_W22_V23_V48_tv1_fakeScrollingPasteSize=&C4_W22_V23_V48_tv1_fillEmptyRows=&C4_W22_V23_V48_tv1_tableIsFiltered=&C4_W22_V23_V48_tv1_multiParameter=0%2F%2F%2F%2F0%2F%2F%2F%2F0%2F%2F%2F%2F0&thtmlbScrollAreaWidth=0&thtmlbScrollAreaHeight=0&LTX_PREFIX_ID=C1_W1_V2_&C1_W1_V2_LTX_VETO_FLAG=&C1_W1_V2_ACTION_GUID=&C1_W1_V2_AC_OBJECT_KEY=&C1_W1_V2_AC_VALUE=&C1_W1_V2_AC_CONTAINER=&C1_W1_V2_MYITSLOCATION=&sap-ajax_request=X", 
		LAST);

	web_custom_request("sam_js2bsp_sender.htm_3", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/sam_sess_queue/sam_js2bsp_sender.htm?sap-session_access_token={C_AccessToken}=", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/mcmain_header.htm", 
		"Snapshot=t95.inf", 
		"Mode=HTML", 
		"Body=queue=http%3A%2F%2Fch2app01.mckesson.com%3A8020%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)%2Fbc%2Fbsp%2Fsap%2Fsam_sess_queue%2Fsam_session_queue_cntrler.do%3Fsap-session_access_token%3D{C_AccessToken}%3D&type=text&data=null&n0=_sam_js_poll&v0=true&n1=_sam_js_client_queue_receiver_name&v1=CL_SAM_CLIENT_QUEUE_RECEIVER&n2=_sam_bsp_session_queue&v2="
		"http%3A%2F%2Fch2app01.mckesson.com%3A8020%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)%2Fbc%2Fbsp%2Fsap%2Fsam_sess_queue%2Fsam_session_queue_cntrler.do%3Fsap-session_access_token%3D{C_AccessToken}%3D&n3=_sam_message_sent_time&v3=Thu%2C%2012%20Oct%202017%2006%3A00%3A31%20UTC", 
		LAST);

	
	lr_end_transaction("CH2_CRM_S01_QryCustIdenScreen_T07_ClkConfirm",LR_AUTO);

	lr_think_time(TT);
		
	
	lr_start_transaction("CH2_CRM_S01_QryCustIdenScreen_T08_ClkEnd");


	web_custom_request("BSPWDApplication.do_4", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/bc/bsp/sap/crm_ui_frame/BSPWDApplication.do", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/bc/bsp/sap/crm_ui_frame/BSPWDApplication.do", 
		"Snapshot=t112.inf", 
		"Mode=HTML", 
		"Body=htmlbevt_ty=htmlb%3Abutton%3Aclick%3A0&htmlbevt_frm=myFormId&htmlbevt_oid=C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_FORWARDCALL&htmlbevt_id=forwardCall&htmlbevt_cnt=0&onInputProcessing=htmlb&SVH_INPUTFIELD_ID=&SVH_INPUTFIELD_VALUE=&thtmlbModifiedInputfieldIds=&sap-htmlb-design=&sap-ajaxtarget=C1_W1_V2_C9_W35_V36_HiddenView.do&sap-ajax_dh_mode=AUTO&wcf-secure-id={c_WcfSecureID}&thtmlbKeyboardFocusId=C13_W51_V52_V55_Confirm&thtmlbKeyboardSelectId=&thtmlbSliderState=&th-navbar-state=&"
		"PREFIX_ID=C9_W35_V36_&C9_W35_V36_SCRATCHPAD_TEXT=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_PREVIOUS_ALERTS=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_PREVIOUS_HASMORE=&C9_W35_V36_CONTEXTAREA_DNISDISPLAY_PREVIOUS_INFO=&C9_W35_V36_CONTEXTAREA_TOPIC_ID=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_MESSAGE=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_HASLINK=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_CODE=AppEventCode&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE1=InteractionEndRequest&"
		"C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE2=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE3=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE4=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE5=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE6=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE7=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE8=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE9=&C9_W35_V36_CONTEXTAREA_ALERTDISPLAY_SELECTED_VALUE10=&"
		"C9_W35_V36_SCRATCHPAD_DUMMY_FIELD=&C9_W35_V36_ACTION_GUID=&C9_W35_V36_AC_OBJECT_KEY=&C9_W35_V36_AC_VALUE=&C9_W35_V36_AC_CONTAINER=&C9_W35_V36_MYITSLOCATION=&C9_W35_V36_POLLFREE_ALERTS=%7B%26%2334%3BAlerts%26%2334%3B%3A%5B%5D%7D&C9_W35_V36_REMOVED_NP_ALERTS=&crmFrwScrollXPos=0&crmFrwScrollYPos=0&crmFrwOldScrollXPos=0&crmFrwOldScrollYPos=0&flashIslandsAsString=&callbackFlashIslands=%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)"
		"%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLBX_FLASH_ISLAND&silverlightIslandsAsString=&callbackSilverlightIslands=%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)%2Fwebcuif%2Fuif_callback%3Fcrm_handler%3DCL_THTMLBX_SILVERLIGHT_ISLAND&th-mes-isex=&C1_W1_V2_V3_V45_bchistory_selection=&C16_W72_V73_btactivityh_struct.priority=5&C16_W72_V73_btactivityh_struct.category=202&C16_W72_V73_btstatush_struct.act_status=E0003&C18_W77_V78_values_tdid="
		"A002&C18_W77_V78_values_tdspras=EN&C18_W77_V78_bttext_tdline=&C20_W82_V83_createfollowup_bttype=ZAT1&C21_W85_V86_V87_activities_editMode=SINGLE&C21_W85_V86_V87_activities_isCellerator=TRUE&C21_W85_V86_V87_activities_selectedRows=&C21_W85_V86_V87_activities_rowCount=3&C21_W85_V86_V87_activities_lastSelectedRow=&C21_W85_V86_V87_activities_visibleFirstRow=1&C21_W85_V86_V87_activities_scrollPosition=&C21_W85_V86_V87_activities_hscrollPosition=&C21_W85_V86_V87_activities_fixedColumns=&"
		"C21_W85_V86_V87_activities_filterApplied=FALSE&C21_W85_V86_V87_activities_firstSelectedRow=&C21_W85_V86_V87_activities_ctrlShiftKeyMode=&C21_W85_V86_V87_activities_previousSelectedRange=&C21_W85_V86_V87_activities_isNavModeActivated=TRUE&C21_W85_V86_V87_activities_tableIsFiltered=&C21_W85_V86_V87_activities_multiParameter=0%2F%2F%2F%2F0%2F%2F%2F%2F0%2F%2F%2F%2F0&thtmlbScrollAreaWidth=0&thtmlbScrollAreaHeight=0&LTX_PREFIX_ID=C1_W1_V2_&C1_W1_V2_LTX_VETO_FLAG=%20&C1_W1_V2_ACTION_GUID=&"
		"C1_W1_V2_AC_OBJECT_KEY=&C1_W1_V2_AC_VALUE=&C1_W1_V2_AC_CONTAINER=&C1_W1_V2_MYITSLOCATION=&sap-ajax_request=X", 
		LAST);

	web_custom_request("sam_js2bsp_sender.htm_4", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/sam_sess_queue/sam_js2bsp_sender.htm?sap-session_access_token={C_AccessToken}=", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/mcmain_header.htm", 
		"Snapshot=t113.inf", 
		"Mode=HTML", 
		"Body=queue=http%3A%2F%2Fch2app01.mckesson.com%3A8020%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)%2Fbc%2Fbsp%2Fsap%2Fsam_sess_queue%2Fsam_session_queue_cntrler.do%3Fsap-session_access_token%3D{C_AccessToken}%3D&type=text&data=null&n0=_sam_js_poll&v0=true&n1=_sam_js_client_queue_receiver_name&v1=CL_SAM_CLIENT_QUEUE_RECEIVER&n2=_sam_bsp_session_queue&v2="
		"http%3A%2F%2Fch2app01.mckesson.com%3A8020%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)%2Fbc%2Fbsp%2Fsap%2Fsam_sess_queue%2Fsam_session_queue_cntrler.do%3Fsap-session_access_token%3D{C_AccessToken}%3D&n3=_sam_message_sent_time&v3=Thu%2C%2012%20Oct%202017%2006%3A00%3A47%20UTC", 
		LAST);

	lr_end_transaction("CH2_CRM_S01_QryCustIdenScreen_T08_ClkEnd",LR_AUTO);

	lr_think_time(TT);

	return 0;
}