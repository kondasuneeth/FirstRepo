
#include "web_api.h"


vuser_end()
{
	lr_start_transaction("CH2_CRM_S01_QryCustIdenScreen_T09_Logout");


	web_submit_data("uif_callback_7", 
		"Action=http://ch2app01.mckesson.com:8020/sap({c_Sid2})/webcuif/uif_callback?sap-client=300&sap-language=EN&sap-domainRelax=min&crm_handler=CL_CRM_UI_FRAME&crm_controller=C1", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?crm-icsessionsyncid=20171012055919.3279330%20&crm-iccc=&crm-icwscl=300&sapouid=00000000&saprole=Y1_IC_AGENT&crm-icsessionid=s_300_Y1_IC_AGENT_1507787965433", 
		"Snapshot=t127.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=cmd", "Value=logoff", ENDITEM, 
		LAST);

	lr_end_transaction("CH2_CRM_S01_QryCustIdenScreen_T09_Logout",LR_AUTO);
	
	  return 0;
}
