#include "web_api.h"
#include "lrw_custom_body.h"
vuser_init()
{
	
	/************************************Filters********************************/
	
	//---------------------404 URLs----------------------
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/favicon.ico",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crmcmp_ic_frame/stylesheets/tabarea/DEFAULT/crmcmp_ic_frame_tabarea.css",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crmcmp_ic_frame/stylesheets/broadcast/ZDEFAULT/crmcmp_ic_frame_broadcast.css",LAST);
//---------------------.Js URLs----------------------
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/public/bc/ur/Design2002/js/sapUrMapi_ie6.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/public/bc/ur/Design2002/js/languages/urMessageBundle_EN.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/thtmlb_scripts/events.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/public/bsp/sap/htmlb/event_dictionary.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/thtmlb_scripts/scripts.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/thtmlb_scripts/calendar.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crm_ui_start/crmuifServer.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crm_ui_start/crmuifClient.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(bD1lbg==)/public/bsp/sap/system/inputvalidation.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/public/bc/ur/sap_secu.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crmcmp_ic_frame/scripts/common/jquery-1.6.2.min.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/crmcmp_ic_frame_blast_shield.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/crmcmp_ic_frame_async_sender.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/crmcmp_ic_frame_utils_map.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/mimc_pathfinder.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/mimc_scratchpad_manager.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/mimc_frame_manager.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/mimc_session_manager.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/mimc_toolbar_manager.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crmcmp_ic_frame/scripts/common/crmcmp_ic_frame_sam_messagewrapper.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/ic_frw_notify/icf_notify_poll.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/sam_sess_queue/sam_js2bsp_message.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/sam_sess_queue/sam_js2bsp_sender.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/sam_sess_queue/sam_js2bsp_receiver.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/scripts/common/jquery-1.6.2.min.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crmcmp_ic_frame/crmcmp_ic_frame_moz_features.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crmcmp_ic_frame/crmcmp_ic_frame_async_sender.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crmcmp_ic_frame/crmcmp_ic_frame_broadcast.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crmcmp_ic_frame/mimc_pathfinder.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crmcmp_ic_frame/crmcmp_ic_frame_im.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crmcmp_ic_frame/crmcmp_ic_frame_moz_features.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crmcmp_ic_frame/crmcmp_ic_frame_async_sender.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crmcmp_ic_frame/crmcmp_ic_frame_broadcast.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crmcmp_ic_frame/mimc_pathfinder.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crmcmp_ic_frame/crmcmp_ic_frame_im.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/ic_base/scripts/common/ic_base_utils_map.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/uicmp_ltx/LaunchTransactionAdmin.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crm_ui_frame/crm_ui_frame_async_sender.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crm_ui_frame/asynchronApplWindowAccess.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/gsbirp/biframecontroller.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/uicmp_ltx/LaunchTransaction.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/ic_base_root_scripts.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/crmcmp_ic_frame_scripts.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/crmcmp_ic_frame_bspinvoke_forwardcall_ajax.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/bspwd_basics/scripts.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/bspwd_basics/breadcrumbs.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/bsp_wd_base/bspwdpopupscripts.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_hdr_std/a.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/crmcmp_ic_frame_sam_event_manager.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/header_jscripts.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/scripts/common/crmcmp_ic_frame_sam_messagewrapper.js",LAST);
web_add_auto_filter("Action=Exclude","URLprefix=http://ch2app01.mckesson.com:8020/sap(====)/bc/bsp/sap/crmcmp_ic_frame/crmcmp_ic_frame_alerts_json.js",LAST);


	web_cleanup_cookies();
	
	web_cache_cleanup();
	
	web_set_max_html_param_len("200000");

	lr_start_transaction("CH2_CRM_S01_QryCustIdenScreen_T01_Homepage");
	
	web_reg_find("Search=All",
		"SaveCount=Homepage_Count",
		"Text=Logon - SAP Web Application Server",
		LAST);

	//<input type="hidden" name="sap-login-XSRF" value="FdUNZRPQnZfHEb7VH0gu-VCxpnD5kSz11N3_JkclA-A&#x3d;">
	web_reg_save_param("c_SAPLogin","LB=name=\"sap-login-XSRF\" value=\"","RB=\">","ORD=1","CONVERT=HTML_TO_TEXT",LAST);
	
	web_url("default.htm", 
		"URL=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crm_ui_frame/default.htm?sap-client=300&sap-sessioncmd=open", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/sap/public/bc/ur/Login/Netweaver/Login_Title.gif", "Referer=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crm_ui_frame/default.htm?sap-client=300&sap-sessioncmd=open", ENDITEM, 
		"Url=/sap/public/bc/ur/Design2002/themes/sap_standard/common/focus/focus.gif?6.0.16.0.0", "Referer=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crm_ui_frame/default.htm?sap-client=300&sap-sessioncmd=open", ENDITEM, 
		"Url=/sap/public/bc/ur/Design2002/themes/sap_standard/common/statusicons/msg/ico12_msg_warning.gif?6.0.16.0.0", "Referer=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crm_ui_frame/default.htm?sap-client=300&sap-sessioncmd=open", ENDITEM, 
		"Url=/sap/public/bc/ur/Design2002/themes/sap_standard/common/loading/loading_ani.gif?6.0.16.0.0", "Referer=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crm_ui_frame/default.htm?sap-client=300&sap-sessioncmd=open", ENDITEM, 
		"Url=/sap/public/bc/ur/Design2002/themes/sap_standard/common/label/3x1_label_designbar.gif?6.0.16.0.0", "Referer=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crm_ui_frame/default.htm?sap-client=300&sap-sessioncmd=open", ENDITEM, 
		"Url=/sap/public/bc/ur/Design2002/themes/sap_standard/common/button/6x1_btn_emph.gif?6.0.16.0.0", "Referer=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crm_ui_frame/default.htm?sap-client=300&sap-sessioncmd=open", ENDITEM, 
		"Url=/sap/public/bc/ur/Design2002/themes/sap_standard/common/button/6x1_btn_emph_hover.gif?6.0.16.0.0", "Referer=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crm_ui_frame/default.htm?sap-client=300&sap-sessioncmd=open", ENDITEM, 
		LAST);

	//lr_end_transaction("CH2_CRM_S01_QryCustIdenScreen_T01_Homepage",LR_AUTO);
	
	lr_stop_transaction("CH2_CRM_S01_QryCustIdenScreen_T01_Homepage");
               
                if(atoi(lr_eval_string("{Homepage_Count}"))>0)
                {
                                             
                lr_end_transaction("CH2_CRM_S01_QryCustIdenScreen_T01_Homepage",LR_PASS);
                }
                else
                {
                lr_error_message("CH2_CRM_S01_QryCustIdenScreen : FAILED TO CLICK HOMEPAGE");     
                lr_end_transaction("CH2_CRM_S01_QryCustIdenScreen_T01_Homepage",LR_FAIL);
                lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_FAIL);
                }
	
	lr_think_time(TT);
	
	web_add_auto_header("location","/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_frame/default.htm?sap-sessioncmd=open");

	lr_start_transaction("CH2_CRM_S01_QryCustIdenScreen_T02_Login");

	web_submit_data("default.htm_3", 
		"Action=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crm_ui_frame/default.htm?sap-sessioncmd=open", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crm_ui_frame/default.htm?sap-sessioncmd=open", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=sap-system-login-oninputprocessing", "Value=onLogin", ENDITEM, 
		"Name=sap-urlscheme", "Value=", ENDITEM, 
		"Name=sap-system-login", "Value=onLogin", ENDITEM, 
		"Name=sap-system-login-basic_auth", "Value=", ENDITEM, 
		"Name=sap-accessibility", "Value=", ENDITEM, 
		"Name=sap-login-XSRF", "Value={c_SAPLogin}", ENDITEM, 
		"Name=sap-system-login-cookie_disabled", "Value=", ENDITEM, 
		"Name=sysid", "Value=CH2", ENDITEM, 
		"Name=sap-client", "Value=300", ENDITEM, 
		"Name=sap-user", "Value={P_Username}", ENDITEM, 
		"Name=sap-password", "Value={P_Password}", ENDITEM, 
		"Name=sap-language", "Value=EN", ENDITEM, 
		EXTRARES, 
		"Url=/SAP(====)/BC/BSP/SAP/thtmlb_styles/sap_skins/default/styling/logo_sap_crm.gif", "Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_frame/newstart.htm", ENDITEM, 
		"Url=/SAP(====)/BC/BSP/SAP/thtmlb_styles/sap_skins/default/styling/uifboxtrans.png", "Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_frame/newstart.htm", ENDITEM, 
		"Url=/SAP(====)/BC/BSP/SAP/thtmlb_styles/sap_skins/default/styling/uifboxtransbl.png", "Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_frame/newstart.htm", ENDITEM, 
		"Url=/SAP(====)/BC/BSP/SAP/thtmlb_styles/sap_skins/default/styling/uifboxtranstl.png", "Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_frame/newstart.htm", ENDITEM, 
		"Url=/SAP(====)/BC/BSP/SAP/thtmlb_styles/sap_skins/default/styling/uifboxtransborders-right.png", "Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_frame/newstart.htm", ENDITEM, 
		"Url=/favicon.ico", "Referer=", ENDITEM, 
		"Url=/SAP(====)/BC/BSP/SAP/thtmlb_styles/sap_skins/default/styling/uifboxtransborders-left.png", "Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_frame/newstart.htm", ENDITEM, 
		"Url=/SAP(====)/BC/BSP/SAP/thtmlb_styles/sap_skins/default/styling/background-button-hover.gif", "Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_frame/newstart.htm", ENDITEM, 
		LAST);

	lr_end_transaction("CH2_CRM_S01_QryCustIdenScreen_T02_Login",LR_AUTO);

	lr_think_time(TT);
	
	lr_start_transaction("CH2_CRM_S01_QryCustIdenScreen_T03_ClkLink");

	web_url("http://ch2app01.mckesson.com:8020/sap/crm_logon?sap-client=300", 
		"URL=http://ch2app01.mckesson.com:8020/sap/crm_logon?sap-client=300", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_frame/newstart.htm", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../sap(bD1lbiZjPTMwMCZkPW1pbg==)/crm_logon/ScreenLoadingAniSmall.gif?session_token=YRft8oE_vDyvFGnjnVyrNg==", "Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/crm_logon/default.htm", ENDITEM, 
		"Url=../SAP(====)/BC/BSP/SAP/thtmlb_styles/sap_skins/default/styling/bullet_black.gif", "Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/crm_logon/default.htm", ENDITEM, 
		"Url=../sap(bD1lbiZjPTMwMCZkPW1pbg==)/crm_logon/saplogo.ico", "Referer=", ENDITEM, 
		LAST);

	web_add_header("X-Requested-With","XMLHttpRequest");
	
	web_add_header("DNT","1");
	//(ZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3PT0=)
	   
	
	web_reg_save_param("c_Sid","LB=(","RB=)","ORD=1","CONVERT=HTML_TO_TEXT",LAST);
	
	web_submit_data("uif_callback", 
		"Action=http://ch2app01.mckesson.com:8020/sap/webcuif/uif_callback?sap-client=300&sap-language=EN&sap-domainRelax=min&crm_handler=CL_CRM_UI_SESSION_MANAGER", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/crm_logon/default.htm", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=cmd", "Value=get_esid", ENDITEM, 
		LAST);

	web_custom_request("uif_callback_2", 
		"URL=http://ch2app01.mckesson.com:8020/sap/webcuif/uif_callback?sap-client=300&sap-language=EN&sap-domainRelax=min&crm_handler=CL_CRM_UI_SESSION_MANAGER", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/crm_logon/default.htm", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"Body=cmd=store_request&esid=({c_Sid})&", 
		EXTRARES, 
		"Url=/SAP(====)/BC/BSP/SAP/thtmlb_styles/sap_skins/default/styling/uifboxtrans.png", "Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/crm_logon/default.htm", ENDITEM, 
		LAST);

	lr_end_transaction("CH2_CRM_S01_QryCustIdenScreen_T03_ClkLink",LR_AUTO);

	lr_think_time(TT);
	
	web_reg_find("Search=Body",
		"SaveCount=ICAgent_Count",
		"Text=MCMAIN",
		LAST);
	
	lr_start_transaction("CH2_CRM_S01_QryCustIdenScreen_T04_ClkIC_Agent");

	web_url("main.htm", 
		"URL=http://ch2app01.mckesson.com:8020/sap({c_Sid})/bc/bsp/sap/crm_ui_frame/main.htm?sap-client=300&sap-language=EN&sap-domainRelax=min&saprole=Y1_IC_AGENT", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/crm_logon/default.htm", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("sap-appcontext=c2FwLXNlc3Npb25pZD1TSUQlM2FBTk9OJTNhY2gyYXBwMDFfQ0gyXzIwJTNhQWwxcmp3dUhfLVdYcTV4Y0cwTFhrUm1sM21FZ2dod0xEZFVfb0NKTy1BVFQ%3d; DOMAIN=ch2app01.mckesson.com");

	//session_access_token\x3dc3N0PUU0QTYyRjA4N0I2NUQxMjVFMjAyN0NCQzY3MjM5OUU3MDA1MDU2ODUwNTMzMUVEN0FCRTI0RjhEMkQ1NUFCMEY\x3d";
	
	web_reg_save_param("C_AccessToken","LB=session_access_token\\x3d","RB=\\x3d\";","ORD=1","Convert=HTML_TO_TEXT",LAST);
		
	web_url("mcmain_header.htm", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/mcmain_header.htm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/mcmain.htm?sap-client=300&sap-domainrelax=min&sap-language=EN", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	web_url("mcmain_tabs.htm", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/mcmain_tabs.htm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/mcmain.htm?sap-client=300&sap-domainrelax=min&sap-language=EN", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_url("broadcast_bar.htm", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/broadcast_bar.htm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/mcmain.htm?sap-client=300&sap-domainrelax=min&sap-language=EN", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("Transform_Messages.do", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/Transform_Messages.do", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/broadcast_bar.htm", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=utf-8", 
		"Body=xml_data=<messages filter=\"0\" >\n  \n    </messages>&do_sort=X", 
		LAST);

	
	web_custom_request("Transform_Messages.do_2", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/Transform_Messages.do", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/broadcast_bar.htm", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=utf-8", 
		"Body=xml_data=<messages filter=\"1\" >\n  \n    </messages>&do_sort=X", 
		LAST);

	web_custom_request("Transform_Messages.do_3", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/Transform_Messages.do", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=1", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/broadcast_bar.htm", 
		"Snapshot=t14.inf", 
		"Body=xml_data=<messages filter=\"1\" ></messages>&do_render=X", 
		LAST);


	web_reg_find("Text=SAP&#x20;-&#x20;&#x5b;&#x5d;", 
		LAST);

	web_url("default.htm_4", 
		"URL=http://ch2app01.mckesson.com:8020/sap/bc/bsp/sap/crm_ui_start/default.htm?sap-accessibility=&sap-rtl=&crm-icsessionsyncid=20171012055919.3279330%20&crm-iccc=&crm-icwscl=300&sap-domainrelax=min&sap-language=EN&sapouid=00000000&sap-client=300&saprole=Y1_IC_AGENT&crm-icsessionid=s_300_Y1_IC_AGENT_1507787965433", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/mcmain.htm?sap-client=300&sap-domainrelax=min&sap-language=EN", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_start/ScreenLoadingAniSmall.gif?session_token=YRft8oE_vDyvFGnjnVyrNg==", "Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?crm-icsessionsyncid=20171012055919.3279330%20&crm-iccc=&crm-icwscl=300&sapouid=00000000&saprole=Y1_IC_AGENT&crm-icsessionid=s_300_Y1_IC_AGENT_1507787965433", ENDITEM, 
		LAST);

	//bEFaNXJy
	//(ZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBPT0=)
	web_reg_save_param("c_Sid2","LB=(","RB=)","ORD=1","CONVERT=HTML_TO_TEXT",LAST);
	
	web_submit_data("uif_callback_3", 
		"Action=http://ch2app01.mckesson.com:8020/sap/webcuif/uif_callback?sap-client=300&sap-language=EN&sap-domainRelax=min&crm_handler=CL_CRM_UI_SESSION_MANAGER", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?crm-icsessionsyncid=20171012055919.3279330%20&crm-iccc=&crm-icwscl=300&sapouid=00000000&saprole=Y1_IC_AGENT&crm-icsessionid=s_300_Y1_IC_AGENT_1507787965433", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=cmd", "Value=get_esid", ENDITEM, 
		LAST);

	web_custom_request("uif_callback_4", 
		"URL=http://ch2app01.mckesson.com:8020/sap/webcuif/uif_callback?sap-client=300&sap-language=EN&sap-domainRelax=min&crm_handler=CL_CRM_UI_SESSION_MANAGER", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?crm-icsessionsyncid=20171012055919.3279330%20&crm-iccc=&crm-icwscl=300&sapouid=00000000&saprole=Y1_IC_AGENT&crm-icsessionid=s_300_Y1_IC_AGENT_1507787965433", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		"Body=cmd=store_request&esid=({c_Sid2})&crm-icsessionsyncid=20171012055919.3279330%20&crm-iccc=&crm-icwscl=300&sapouid=00000000&saprole=Y1_IC_AGENT&crm-icsessionid=s_300_Y1_IC_AGENT_1507787965433", 
		LAST);


	web_url("main.htm_2", 
		"URL=http://ch2app01.mckesson.com:8020/sap({c_Sid2})/bc/bsp/sap/crm_ui_frame/main.htm?sap-client=300&sap-language=EN&sap-domainRelax=min&saprole=Y1_IC_AGENT", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1lbiZjPTMwMCZkPW1pbg==)/bc/bsp/sap/crm_ui_start/default.htm?crm-icsessionsyncid=20171012055919.3279330%20&crm-iccc=&crm-icwscl=300&sapouid=00000000&saprole=Y1_IC_AGENT&crm-icsessionid=s_300_Y1_IC_AGENT_1507787965433", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	
	web_url("main.htm_3", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/bc/bsp/sap/crm_ui_frame/main.htm", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/main.htm?crm-iccc=&crm-icsessionid=s_300_Y1_IC_AGENT_1507787965433&crm-icsessionsyncid=20171012055919.3279330&#x20;&crm-icwscl=300&sap-client=300&sap-domainrelax=min&sap-language=EN", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);
	
	
	web_reg_save_param("c_WcfSecureID","LB=\"wcf-secure-id\" value=\"","RB=\"","ORD=1",LAST);
	
	web_url("main.htm_10", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/bc/bsp/sap/crm_ui_frame/BSPWDApplication.do", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0bEFaNXJyckVBJTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/main.htm?crm-iccc=&crm-icsessionid=s_300_Y1_IC_AGENT_1507787965433&crm-icsessionsyncid=20171012055919.3279330&#x20;&crm-icwscl=300&sap-client=300&sap-domainrelax=min&sap-language=EN", 
		"Snapshot=t323.inf", 
		"Mode=HTML", 
		LAST);
	

	web_custom_request("sam_js2bsp_sender.htm", 
		"URL=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/sam_sess_queue/sam_js2bsp_sender.htm?sap-session_access_token={C_AccessToken}=", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://ch2app01.mckesson.com:8020/sap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)/bc/bsp/sap/crmcmp_ic_frame/mcmain_header.htm", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"Body=queue=http%3A%2F%2Fch2app01.mckesson.com%3A8020%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)%2Fbc%2Fbsp%2Fsap%2Fsam_sess_queue%2Fsam_session_queue_cntrler.do%3Fsap-session_access_token%3D{C_AccessToken}%3D&type=text&data=null&n0=_sam_js_poll&v0=true&n1=_sam_js_client_queue_receiver_name&v1=CL_SAM_CLIENT_QUEUE_RECEIVER&n2=_sam_bsp_session_queue&v2="
		"http%3A%2F%2Fch2app01.mckesson.com%3A8020%2Fsap(bD1FTiZjPTMwMCZpPTEmZT1WRXhRV0V0Q1JsOWZYMTlmTVRNd05EZGZBRkJXaFFVekh0ZXI0azVxVWRQckR3JTNkJTNk)%2Fbc%2Fbsp%2Fsap%2Fsam_sess_queue%2Fsam_session_queue_cntrler.do%3Fsap-session_access_token%3D{C_AccessToken}%3D&n3=_sam_message_sent_time&v3=Thu%2C%2012%20Oct%202017%2005%3A59%3A31%20UTC", 
		LAST);

	
	//lr_end_transaction("CH2_CRM_S01_QryCustIdenScreen_T04_ClkIC_Agent",LR_AUTO);
	lr_stop_transaction("CH2_CRM_S01_QryCustIdenScreen_T04_ClkIC_Agent");
               
                if(atoi(lr_eval_string("{ICAgent_Count}"))>0)
                {
                                             
                lr_end_transaction("CH2_CRM_S01_QryCustIdenScreen_T04_ClkIC_Agent",LR_PASS);
                }
                else
                {
                lr_error_message("CH2_CRM_S01_QryCustIdenScreen : FAILED TO CLICK IC_AGENT");     
                lr_end_transaction("CH2_CRM_S01_QryCustIdenScreen_T04_ClkIC_Agent",LR_FAIL);
                lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_FAIL);
                }

	lr_think_time(TT);
	
	return 0;
}
