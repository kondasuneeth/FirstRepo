#include "web_api.h"
#include "lrw_custom_body.h"
vuser_init()
{
	

              
	
	return 0;
}
